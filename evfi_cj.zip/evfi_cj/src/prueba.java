import javax.swing.*;

public class prueba {
    private JPanel miPanel;
    private JTabbedPane tabbedPane1;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;

}
